package com.imcsk.service;

import com.imcsk.entity.ResultBean;

public interface IGetOneDataService {
    ResultBean getOneData();
}
