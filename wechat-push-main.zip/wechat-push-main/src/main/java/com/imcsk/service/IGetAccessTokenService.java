package com.imcsk.service;

import com.imcsk.entity.ResultBean;

public interface IGetAccessTokenService {
    ResultBean getAccessToken();
}
