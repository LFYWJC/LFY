package com.imcsk.service;

import com.imcsk.entity.ResultBean;

public interface IFlatterService {
    ResultBean getFlatter();
}
