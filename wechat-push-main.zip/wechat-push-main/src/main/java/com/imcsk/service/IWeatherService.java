package com.imcsk.service;

import com.imcsk.entity.ResultBean;

/**
 * @Description: 获取天气相关信息
 * @Author csk
 * @Date: 2022/9/1
 */
public interface IWeatherService {
    ResultBean getWeather();
}
