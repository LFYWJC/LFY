package com.imcsk.service;

import com.imcsk.entity.ResultBean;

/**
 * @Description COVID-19数据查询
 * @Author csk
 * @Date 2022/10/15
 */
public interface ICovidDataQueryService {
    ResultBean getCovidData();
}
