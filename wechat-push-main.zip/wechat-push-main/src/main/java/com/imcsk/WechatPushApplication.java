package com.imcsk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author csk
 * @Date 2022/8/31
 */
@SpringBootApplication
public class WechatPushApplication {
    public static void main(String[] args) {
        SpringApplication.run(WechatPushApplication.class, args);
    }
}
