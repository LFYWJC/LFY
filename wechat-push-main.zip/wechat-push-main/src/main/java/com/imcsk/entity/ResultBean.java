package com.imcsk.entity;

import org.springframework.stereotype.Component;

/**
 * @Description 响应数据实体类
 * @Author csk
 * @Date 2022/8/31
 */
@Component
public class ResultBean {
    private String code;
    private String message;
    private Object data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
